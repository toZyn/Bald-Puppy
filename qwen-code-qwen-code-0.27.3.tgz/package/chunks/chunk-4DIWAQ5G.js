// Force strict mode and setup for ESM
"use strict";
import{init_esbuild_shims}from"./chunk-VKDAXTCZ.js";import{__name}from"./chunk-KBWJGX7I.js";init_esbuild_shims();var usageProvenance=new WeakMap;function setGenAiUsageProvenance(usage,provenance){usageProvenance.set(usage,provenance)}__name(setGenAiUsageProvenance,"setGenAiUsageProvenance");function getGenAiUsageProvenance(usage){return usage?usageProvenance.get(usage):void 0}__name(getGenAiUsageProvenance,"getGenAiUsageProvenance");function outputIncludesThoughts(authType){return authType==="openai"||authType==="openai-responses"||authType==="qwen-oauth"}__name(outputIncludesThoughts,"outputIncludesThoughts");function outputTokenCount(counts,authType){const derived=counts.total-counts.input;if(counts.total>0&&derived>=counts.output&&derived<=counts.output+counts.thoughts)return derived;return outputIncludesThoughts(authType)?counts.output:counts.output+counts.thoughts}__name(outputTokenCount,"outputTokenCount");export{setGenAiUsageProvenance,getGenAiUsageProvenance,outputIncludesThoughts,outputTokenCount};
/**
 * @license
 * Copyright 2026 Qwen Team
 * SPDX-License-Identifier: Apache-2.0
 */
