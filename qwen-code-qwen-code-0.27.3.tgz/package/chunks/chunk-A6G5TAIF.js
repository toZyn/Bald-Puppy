// Force strict mode and setup for ESM
"use strict";
import{init_esbuild_shims}from"./chunk-VKDAXTCZ.js";import{__name}from"./chunk-KBWJGX7I.js";init_esbuild_shims();var EXTRACT_NOOP_SKIP_TURNS_ENV="QWEN_CODE_MEMORY_EXTRACT_NOOP_SKIP_TURNS";var MAX_EXTRACT_NOOP_SKIP_TURNS=3;var EXTRACT_TAIL_ENTRIES=40;var EXTRACT_CADENCE_MAX_PENDING_ENTRIES=EXTRACT_TAIL_ENTRIES/2;function getExtractNoopSkipTurns(){const raw=process.env[EXTRACT_NOOP_SKIP_TURNS_ENV]?.trim();if(!raw||!/^\d+$/.test(raw))return 0;return Math.min(Number(raw),MAX_EXTRACT_NOOP_SKIP_TURNS)}__name(getExtractNoopSkipTurns,"getExtractNoopSkipTurns");export{EXTRACT_NOOP_SKIP_TURNS_ENV,EXTRACT_TAIL_ENTRIES,EXTRACT_CADENCE_MAX_PENDING_ENTRIES,getExtractNoopSkipTurns};
/**
 * @license
 * Copyright 2026 Qwen Team
 * SPDX-License-Identifier: Apache-2.0
 */
