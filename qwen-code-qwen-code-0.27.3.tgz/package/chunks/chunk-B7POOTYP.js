// Force strict mode and setup for ESM
"use strict";
import{parse}from"./chunk-YJENXDMX.js";import{external_exports}from"./chunk-KZSUHQLD.js";import{normalizeContent}from"./chunk-DBRQGEEI.js";import{init_esbuild_shims}from"./chunk-VKDAXTCZ.js";import{__name}from"./chunk-KBWJGX7I.js";init_esbuild_shims();var MarkdownCommandDefSchema=external_exports.object({frontmatter:external_exports.object({description:external_exports.string().optional(),"argument-hint":external_exports.string().optional(),when_to_use:external_exports.string().optional(),"disable-model-invocation":external_exports.boolean().optional()}).passthrough().optional(),prompt:external_exports.string({error:__name(issue=>issue.input===void 0?"The prompt content is required.":"The prompt content must be a string.","error")})});function parseMarkdownCommand(content){const normalizedContent=normalizeContent(content);const frontmatterRegex=/^---\n(?:([\s\S]*?)\n)?---(?:\n|$)([\s\S]*)$/;const match=normalizedContent.match(frontmatterRegex);if(!match){return{prompt:normalizedContent.trim()}}const[,frontmatterYaml="",body]=match;let frontmatter;if(frontmatterYaml.trim()){try{frontmatter=parse(frontmatterYaml)}catch(error){throw new Error(`Failed to parse YAML frontmatter: ${error instanceof Error?error.message:String(error)}`)}}return{frontmatter,prompt:body.trim()}}__name(parseMarkdownCommand,"parseMarkdownCommand");export{MarkdownCommandDefSchema,parseMarkdownCommand};
/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
