// Force strict mode and setup for ESM
"use strict";
import{init_esbuild_shims}from"./chunk-VKDAXTCZ.js";import{__name}from"./chunk-KBWJGX7I.js";init_esbuild_shims();function parseToolCallArguments(json){try{const value=JSON.parse(json);if(typeof value!=="object"||value===null||Array.isArray(value)){return{ok:false,reason:"NON_OBJECT"}}return{ok:true,value}}catch{return{ok:false,reason:"MALFORMED_JSON"}}}__name(parseToolCallArguments,"parseToolCallArguments");export{parseToolCallArguments};
/**
 * @license
 * Copyright 2025 Qwen
 * SPDX-License-Identifier: Apache-2.0
 */
