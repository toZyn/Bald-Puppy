// Force strict mode and setup for ESM
"use strict";
import{init_esbuild_shims}from"./chunk-VKDAXTCZ.js";init_esbuild_shims();import{AsyncLocalStorage}from"node:async_hooks";var openaiRequestCaptureContext=new AsyncLocalStorage;export{openaiRequestCaptureContext};
/**
 * @license
 * Copyright 2025 Qwen
 * SPDX-License-Identifier: Apache-2.0
 */
