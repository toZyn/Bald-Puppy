// Force strict mode and setup for ESM
"use strict";
import{init_esbuild_shims}from"./chunk-VKDAXTCZ.js";import{__name}from"./chunk-KBWJGX7I.js";init_esbuild_shims();function peerMessagingOffReason(config){if(config.isSafeMode?.()){return"--safe-mode (or QWEN_CODE_SAFE_MODE) disables peer messaging, and agents.crossSessionMessaging may also be off"}return"this session publishes no peer inbox address"}__name(peerMessagingOffReason,"peerMessagingOffReason");export{peerMessagingOffReason};
/**
 * @license
 * Copyright 2026 Qwen
 * SPDX-License-Identifier: Apache-2.0
 */
