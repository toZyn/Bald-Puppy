// Force strict mode and setup for ESM
"use strict";
import{init_esbuild_shims}from"./chunk-VKDAXTCZ.js";init_esbuild_shims();var AuthType=(AuthType2=>{AuthType2["USE_OPENAI"]="openai";AuthType2["USE_OPENAI_RESPONSES"]="openai-responses";AuthType2["QWEN_OAUTH"]="qwen-oauth";AuthType2["QWEN_SUBSCRIPTION"]="qwen-subscription";AuthType2["USE_GEMINI"]="gemini";AuthType2["USE_VERTEX_AI"]="vertex-ai";AuthType2["USE_ANTHROPIC"]="anthropic";return AuthType2})(AuthType||{});export{AuthType};
/**
 * @license
 * Copyright 2025 Google LLC
 * Copyright 2026 Qwen Team
 * SPDX-License-Identifier: Apache-2.0
 */
