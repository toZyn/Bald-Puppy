// Force strict mode and setup for ESM
"use strict";
import{init_esbuild_shims}from"./chunk-VKDAXTCZ.js";import{__name}from"./chunk-KBWJGX7I.js";init_esbuild_shims();var preparationsByResponse=new WeakMap;function setToolCallPreparations(response,preparations){preparationsByResponse.set(response,preparations)}__name(setToolCallPreparations,"setToolCallPreparations");function getToolCallPreparations(response){return preparationsByResponse.get(response)??[]}__name(getToolCallPreparations,"getToolCallPreparations");init_esbuild_shims();var InvalidStreamError=class extends Error{static{__name(this,"InvalidStreamError")}type;constructor(message,type){super(message);this.name="InvalidStreamError";this.type=type}};export{setToolCallPreparations,getToolCallPreparations,InvalidStreamError};
/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
/**
 * @license
 * Copyright 2025 Qwen
 * SPDX-License-Identifier: Apache-2.0
 */
