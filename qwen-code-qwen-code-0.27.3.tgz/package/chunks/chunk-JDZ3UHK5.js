// Force strict mode and setup for ESM
"use strict";
import{init_esbuild_shims}from"./chunk-VKDAXTCZ.js";import{__name}from"./chunk-KBWJGX7I.js";init_esbuild_shims();import*as os from"node:os";import*as path from"node:path";function normalizeProjectRoot(projectRoot){const resolved=path.resolve(projectRoot);return os.platform()==="win32"?resolved.toLowerCase():resolved}__name(normalizeProjectRoot,"normalizeProjectRoot");export{normalizeProjectRoot};
/**
 * @license
 * Copyright 2025 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
