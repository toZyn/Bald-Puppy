// Force strict mode and setup for ESM
"use strict";
import{init_esbuild_shims}from"./chunk-VKDAXTCZ.js";import{__name}from"./chunk-KBWJGX7I.js";init_esbuild_shims();function resolveGithubWebOrigin(baseUrl){const raw=typeof baseUrl==="string"&&baseUrl.trim()?baseUrl.trim():"https://api.github.com";return raw.replace(/\/api\/v3\/?$/,"").replace(/^https:\/\/api\.github\.com/,"https://github.com").replace(/^https:\/\/api\.([^./]+\.ghe\.com)/i,"https://$1").replace(/\/+$/,"")}__name(resolveGithubWebOrigin,"resolveGithubWebOrigin");export{resolveGithubWebOrigin};
/**
 * @license
 * Copyright 2026 Qwen Team
 * SPDX-License-Identifier: Apache-2.0
 */
