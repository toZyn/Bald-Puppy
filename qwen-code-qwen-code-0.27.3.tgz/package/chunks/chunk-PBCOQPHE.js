// Force strict mode and setup for ESM
"use strict";
import{init_esbuild_shims}from"./chunk-VKDAXTCZ.js";import{__name}from"./chunk-KBWJGX7I.js";init_esbuild_shims();var GATE_OUTPUT_BUDGET_BYTES=12*1024;function jsonBytes(value){const line=JSON.stringify(value);const lessThan=line.match(/</g)?.length??0;return Buffer.byteLength(line,"utf8")+3*lessThan}__name(jsonBytes,"jsonBytes");export{GATE_OUTPUT_BUDGET_BYTES,jsonBytes};
/**
 * @license
 * Copyright 2026 Qwen Team
 * SPDX-License-Identifier: Apache-2.0
 */
