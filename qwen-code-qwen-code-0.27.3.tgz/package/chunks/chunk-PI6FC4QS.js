// Force strict mode and setup for ESM
"use strict";
import{init_esbuild_shims}from"./chunk-VKDAXTCZ.js";init_esbuild_shims();var WORKSPACE_SKILLS_REVALIDATE_INTERVAL_MS=1e3;var WORKSPACE_SKILLS_REVALIDATE_TIMEOUT_MS=5e3;export{WORKSPACE_SKILLS_REVALIDATE_INTERVAL_MS,WORKSPACE_SKILLS_REVALIDATE_TIMEOUT_MS};
/**
 * @license
 * Copyright 2026 Qwen Team
 * SPDX-License-Identifier: Apache-2.0
 */
