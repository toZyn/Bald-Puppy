// Force strict mode and setup for ESM
"use strict";
import{init_esbuild_shims}from"./chunk-VKDAXTCZ.js";init_esbuild_shims();var MCP_OAUTH_CLIENT_NAME="Qwen Code MCP Client";var MCP_SA_IMPERSONATION_CLIENT_NAME="Qwen Code (Service Account Impersonation)";var OAUTH_REDIRECT_PORT=7777;var OAUTH_REDIRECT_PATH="/oauth/callback";export{MCP_OAUTH_CLIENT_NAME,MCP_SA_IMPERSONATION_CLIENT_NAME,OAUTH_REDIRECT_PORT,OAUTH_REDIRECT_PATH};
/**
 * @license
 * Copyright 2025 Qwen
 * SPDX-License-Identifier: Apache-2.0
 */
