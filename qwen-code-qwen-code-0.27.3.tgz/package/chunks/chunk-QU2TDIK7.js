// Force strict mode and setup for ESM
"use strict";
import{init_esbuild_shims}from"./chunk-VKDAXTCZ.js";init_esbuild_shims();var GIT_COMMIT_INFO="8423e47";var CLI_VERSION="0.27.3";export{GIT_COMMIT_INFO,CLI_VERSION};
/**
 * @license
 * Copyright 2026 Google LLC
 * SPDX-License-Identifier: Apache-2.0
 */
