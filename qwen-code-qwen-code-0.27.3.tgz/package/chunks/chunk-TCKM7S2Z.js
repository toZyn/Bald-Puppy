// Force strict mode and setup for ESM
"use strict";
import{init_esbuild_shims}from"./chunk-VKDAXTCZ.js";import{__name}from"./chunk-KBWJGX7I.js";init_esbuild_shims();var PathMutexRegistry=class{static{__name(this,"PathMutexRegistry")}tails=new Map;async runExclusive(key,fn,signal){signal?.throwIfAborted();const previous=this.tails.get(key)??Promise.resolve();let release;const current=new Promise(resolve=>{release=resolve});const tail=previous.catch(()=>void 0).then(()=>current);this.tails.set(key,tail);void tail.then(()=>{if(this.tails.get(key)===tail)this.tails.delete(key)});try{if(signal){await new Promise((resolve,reject)=>{const onAbort=__name(()=>{signal.removeEventListener("abort",onAbort);reject(signal.reason)},"onAbort");signal.addEventListener("abort",onAbort,{once:true});void previous.catch(()=>void 0).then(()=>{signal.removeEventListener("abort",onAbort);resolve()});if(signal.aborted)onAbort()})}else{await previous.catch(()=>void 0)}signal?.throwIfAborted();return await fn()}finally{release()}}};export{PathMutexRegistry};
/**
 * @license
 * Copyright 2025 Qwen Team
 * SPDX-License-Identifier: Apache-2.0
 */
